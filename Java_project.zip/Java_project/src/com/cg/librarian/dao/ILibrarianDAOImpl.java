package com.cg.librarian.dao;

import java.util.List;

import com.cg.librarian.bean.LibrarianBean;

public class ILibrarianDAOImpl implements ILibrarianDAO{

	@Override
	public String addBook(LibrarianBean librarian) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LibrarianBean search(String bookId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List retrieveAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
