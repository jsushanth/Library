package com.cg.librarian.exception;

public class LibrarianException extends Exception{
	LibrarianException(String obj){
		System.out.println(obj);
	}

}
