package com.cg.librarian.pl;

import java.util.Scanner;

import com.cg.librarian.bean.LibrarianBean;
import com.cg.librarian.service.ILibrarianService;
import com.cg.librarian.service.LibrarianServiceImpl;

public class LibrarianMain {
Scanner scan=new Scanner(System.in);
static ILibrarianService libraraianService=null;
static LibrarianServiceImpl librarianServiceImpl=null;
public static void main(String[] args) {
	LibrarianBean librarian=null;
	System.out.println("Library Management System");
	System.out.println("--------------------------------");
	System.out.println("1.Add Book");
	System.out.println("2.Search Book");
	System.out.println("3.RetrieveAll details");
	System.out.println("4.Exit");
	
}
}
