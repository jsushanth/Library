package com.cg.librarian.service;

import java.util.List;

import com.cg.librarian.bean.LibrarianBean;
import com.cg.librarian.exception.LibrarianException;

public class LibrarianServiceImpl implements ILibrarianService{

	@Override
	public String addBook(LibrarianBean librarian) throws LibrarianException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LibrarianBean search(String bookId) throws LibrarianException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List retrieveAll() throws LibrarianException {
		// TODO Auto-generated method stub
		return null;
	}

}
