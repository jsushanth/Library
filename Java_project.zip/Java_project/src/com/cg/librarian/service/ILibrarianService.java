package com.cg.librarian.service;

import java.util.List;

import com.cg.librarian.bean.LibrarianBean;
import com.cg.librarian.exception.LibrarianException;

public interface ILibrarianService {
	public String addBook(LibrarianBean librarian)throws LibrarianException;
	public LibrarianBean search(String bookId)throws LibrarianException;
	public List retrieveAll()throws LibrarianException;
}
